from flask import Flask, render_template, request, redirect
import mysql.connector
from datetime import date

app = Flask(__name__)

# Database connection (XAMPP MySQL)
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="manasvi.db"  # <-- your database name in XAMPP
)
cur = conn.cursor(dictionary=True)  # dictionary=True makes fetching easier

# ===== Home Page =====
@app.route('/')
def home():
    return render_template('home.html')

# ===== Add Customer =====
@app.route('/add_customer', methods=['GET', 'POST'])
def add_customer():
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['mobile']   # form input 'mobile'
        address = request.form['city']   # form input 'city'
        cur.execute("INSERT INTO Customer (name, phone, address) VALUES (%s, %s, %s)", (name, phone, address))
        conn.commit()

        return redirect('/view_customers')
    return render_template('add_customer.html')

# ===== View Customers =====
@app.route('/view_customers')
def view_customers():
    cur.execute("SELECT * FROM Customer")
    data = cur.fetchall()
    return render_template('view_customer.html', customers=data)

# ===== Deposit =====
@app.route('/deposit', methods=['GET', 'POST'])
def deposit():
    if request.method == 'POST':
        acc_no = request.form['acc_no']
        amount = float(request.form['amount'])
        # Update balance
        cur.execute("UPDATE Account SET Balance = Balance + %s WHERE Account_No = %s", (amount, acc_no))
        # Record transaction
        cur.execute("INSERT INTO Transaction_Table (Account_No, Trans_Type, Amount, Trans_Date) VALUES (%s, %s, %s, %s)",
                    (acc_no, 'Deposit', amount, date.today()))
        conn.commit()
        return "Deposit Successful!"
    return render_template('deposit.html')

# ===== Withdraw =====
@app.route('/withdraw', methods=['GET', 'POST'])
def withdraw():
    if request.method == 'POST':
        acc_no = request.form['acc_no']
        amount = float(request.form['amount'])
        # Get current balance
        cur.execute("SELECT Balance FROM Account WHERE Account_No=%s", (acc_no,))
        result = cur.fetchone()
        if result is None:
            return "Account not found!"
        balance = result['Balance']
        if balance >= amount:
            cur.execute("UPDATE Account SET Balance = Balance - %s WHERE Account_No = %s", (amount, acc_no))
            cur.execute("INSERT INTO Transaction_Table (Account_No, Trans_Type, Amount, Trans_Date) VALUES (%s, %s, %s, %s)",
                        (acc_no, 'Withdraw', amount, date.today()))
            conn.commit()
            return "Withdrawal Successful!"
        else:
            return "Insufficient Balance!"
    return render_template('withdraw.html')

# ===== View Accounts =====
@app.route('/view_accounts')
def view_accounts():
    cur.execute("""
        SELECT a.Account_No, a.Type, a.Balance, c.name AS customer_name, b.Branch_Name
        FROM Account a
        JOIN Customer c ON a.Customer_ID = c.id
        JOIN Branch b ON a.Branch_ID = b.Branch_ID
    """)
    data = cur.fetchall()
    return render_template('view_accounts.html', accounts=data)

# ===== View Transactions =====
@app.route('/view_transactions')
def view_transactions():
    cur.execute("""
        SELECT Trans_ID, Account_No, Trans_Type, Amount, Trans_Date
        FROM Transaction_Table
    """)
    data = cur.fetchall()
    return render_template('view_transactions.html', transactions=data)

if __name__ == '__main__':
    app.run(debug=True)
